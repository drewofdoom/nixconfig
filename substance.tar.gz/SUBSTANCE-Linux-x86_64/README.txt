SUBSTANCE · Hybrid Bass Engine
Linux x86_64 package, build 1.0.1

Contents
--------
SUBSTANCE.vst3               VST3 plugin bundle
SUBSTANCE                    Standalone application
install.sh                   User-local installer
MANUAL_SUBSTANCE_EN.pdf      Manual, English
MANUAL_SUBSTANCE_PT-BR.pdf   Manual, Portuguese

Requirements
------------
glibc 2.30 or newer: Ubuntu 20.04, Debian 11, Fedora 32 and anything after.
The 1.0 Linux build needed glibc 2.43 and did not load on most distros
("GLIBC_2.43 not found"). 1.0.1 fixes that. The sound engine is the same.

libcurl is used only while activating Pro. Any libcurl.so.4 works.

Install
-------
1. Open a terminal in this folder.
2. Run: ./install.sh
3. Restart your DAW and rescan VST3 plugins if necessary.

Run standalone
--------------
./SUBSTANCE

The installer does not require root access. It installs the plugin in ~/.vst3
and creates ~/.local/bin/substance. Existing plugins are moved to a timestamped
backup before replacement.

The 15-day Pro trial starts from the SUBSTANCE welcome screen. After the trial,
the Free mode continues to process real bass audio.

Activate Pro
------------
After an approved Pro purchase, select ACTIVATE PRO on the welcome screen and
paste the license received by email. One Pro license supports up to two
computers. Internet access is required only while activating.
