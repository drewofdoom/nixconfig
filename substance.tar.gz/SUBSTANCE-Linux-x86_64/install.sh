#!/usr/bin/env bash
set -euo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VST3_DIR="${HOME}/.vst3"
BIN_DIR="${HOME}/.local/bin"
mkdir -p "${VST3_DIR}" "${BIN_DIR}"

if [[ -e "${VST3_DIR}/SUBSTANCE.vst3" ]]; then
  backup="${VST3_DIR}/SUBSTANCE.vst3.backup-$(date +%Y%m%d-%H%M%S)"
  mv "${VST3_DIR}/SUBSTANCE.vst3" "${backup}"
  echo "Previous VST3 preserved at: ${backup}"
fi

if [[ -e "${VST3_DIR}/MR_ROSS.vst3" ]]; then
  backup="${VST3_DIR}/MR_ROSS.vst3.backup-$(date +%Y%m%d-%H%M%S)"
  mv "${VST3_DIR}/MR_ROSS.vst3" "${backup}"
  echo "Legacy MR_ROSS VST3 preserved at: ${backup}"
fi

cp -a "${PACKAGE_DIR}/SUBSTANCE.vst3" "${VST3_DIR}/SUBSTANCE.vst3"
ln -sfn "${PACKAGE_DIR}/SUBSTANCE" "${BIN_DIR}/substance"

echo
echo "SUBSTANCE installed."
echo "VST3: ${VST3_DIR}/SUBSTANCE.vst3"
echo "Standalone: ${BIN_DIR}/substance"
echo "Restart your DAW and rescan VST3 plugins if necessary."
